<style>
	table{padding:5px;border-radius:5px}
	td{padding:10px}
</style>
<table width="90%" border="1" align="center">
  <tr style="background:#CCCCCC" height="30px">
    <th colspan="2" style="color:#0000FF">Contact Us</th>
  </tr>
  <tr>
    <td width="121" height="37">Name</td>
    <td width="252">Sanjeev Kumar </td>
  </tr>
  <tr>
    <td height="36">Mobile </td>
    <td> 9015501897 </td>
  </tr>
  <tr>
    <td>Add</td>
    <td>141 Dhakka Near kingsway camp Delhi 110009 </td>
  </tr>
    <tr>
    <td>Email</td>
    <td>phptpoint@gmail.com</td>
  </tr>
   <tr>
    <td>Website</td>
    <td><a href="http://www.phptpoint.com">www.phptpoint.com</a></td>
  </tr>
  
</table>
