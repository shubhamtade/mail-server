<h3>Welcme <?php session_start();
 	echo @$_SESSION['sname'];
 ?>
Your account has beeb created 
to access your accout <a href="index.php?chk=3">Click here</a></h2>